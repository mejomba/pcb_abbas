
students = [

    {"name": "Reza", "grade": 17},

    {"name": "Sara", "grade": 19},

    {"name": "Ali", "grade": 17},

    {"name": "Mina", "grade": 20},
{"name": "Hadi", "grade": 17},
    {"name": "Nima", "grade": 17},

]
sorted_students = sorted(students, key=lambda x: x["grade"] , reverse=True)
print(sorted_students)
for i in range(len(sorted_students) -1):
    if sorted_students[i]["grade"] == sorted_students[i - 1]["grade"]:
        new_sorted = sorted(sorted_students, key=lambda x: x["name"] ,reverse=True)
        print(new_sorted)
